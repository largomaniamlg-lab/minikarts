"""Exercise the real WebSocket server with sixteen independent connections."""
import asyncio
import json
import sys
import os
import websockets

async def receive(ws, kind, predicate=lambda m: True):
    async with asyncio.timeout(10):
        while True:
            message = json.loads(await ws.recv())
            if message['type'] == kind and predicate(message):
                return message

async def send(ws, **message):
    await ws.send(json.dumps(message))

async def main():
    url = sys.argv[1] if len(sys.argv) > 1 else 'ws://127.0.0.1:8080'
    track=int(os.environ.get("MINIKARTS_TEST_TRACK","0"))
    clients = []
    try:
        for index in range(16):
            ws = await websockets.connect(url, max_queue=None, close_timeout=1)
            clients.append(ws)
            await send(ws, type='ping', stamp=index + 0.25)
            assert (await receive(ws, 'pong'))['stamp'] == index + 0.25
            await send(ws, type='list')
            directory = await receive(ws, 'rooms')
            if index:
                selected = next(r for r in directory['rooms'] if r['code'] == code)
                assert selected['players'] == index and selected['host'] == 'Amigo 1'
                code = selected['code']
            await send(ws, type='create' if index == 0 else 'join', code='' if index == 0 else code, name=f'Amigo {index + 1}', driver=index % 16, laps=9, track=track)
            welcome = await receive(ws, 'welcome')
            code = welcome['code']
        state = await receive(clients[0], 'state', lambda m: len(m['players']) == 16)
        assert len({p['id'] for p in state['players']}) == 16
        assert state['laps'] == 9
        assert isinstance(state['time'], (int, float))
        assert all(len(p['velocity']) == 3 for p in state['players'])
        assert len(state['boxes']) == (8 if track==0 else 18)
        assert {p['driver'] for p in state['players']} == set(range(16))
        assert len(state['neutral']) == 3
        async with websockets.connect(url, max_queue=None, close_timeout=1) as extra:
            await send(extra, type='list')
            directory = await receive(extra, 'rooms')
            assert not any(r['code'] == code for r in directory['rooms']), 'Full rooms hidden'
            await send(extra, type='join', code=code, name='Decimoséptimo')
            error = await receive(extra, 'error')
            assert 'llena' in error['message']
        await send(clients[1], type='start')
        assert 'creador' in (await receive(clients[1], 'error'))['message']
        await send(clients[0], type='start')
        assert 'Listo' in (await receive(clients[0], 'error'))['message']
        for ws in clients:
            await send(ws, type='ready', ready=True)
        await receive(clients[0], 'state', lambda m: all(p['ready'] for p in m['players']))
        await send(clients[0], type='start')
        state = await receive(clients[0], 'state', lambda m: m['phase'] == 'countdown')
        assert all(abs(p['speed']) < 0.01 for p in state['players'])
        state = await receive(clients[0], 'state', lambda m: m['phase'] == 'racing')
        origins = {p['id']: p['position'] for p in state['players']}
        for _ in range(20):
            for ws in clients:
                await send(ws, type='input', controls={'accelerate': 1}, lap=3, position=[999,999,999])
            await asyncio.sleep(.05)
        state = await receive(clients[0], 'state', lambda m: m['elapsed'] > .8)
        assert all(p['lap'] == 0 for p in state['players']), 'Client cannot forge laps'
        assert all(p['position'][0] < (100 if track==0 else 700) for p in state['players']), 'Client cannot teleport'
        assert any(p['position'] != origins[p['id']] for p in state['players'])
        assert any(p['speed'] > 1 for p in state['players'])
        assert all(abs(p['speed']) <= 65 / 3.6 + .01 for p in state['players']), 'Authoritative speed cap'
        for ws in clients:
            await send(ws, type='input', controls={'accelerate': 1, 'shoot': 1})
        await receive(clients[0], 'state', lambda m: m['elapsed'] > state['elapsed'])
        host = state['host']
        await clients[0].close()
        state = await receive(clients[1], 'state', lambda m: len(m['players']) == 15)
        assert state['host'] != host, 'Host migration after disconnect'
        print('PASS: listado y entrada por selección, 16 clientes, capacidad, autoridad, listos, cuenta atrás, movimiento, disparos solicitados y desconexión')
    finally:
        for ws in clients:
            await ws.close()

asyncio.run(main())
